# EXAMPLE: Auditor Training

auditor = read.table("AuditorTraining.txt", header = T)
head(auditor)
View(auditor)

auditor$block = as.factor(auditor$block)
auditor$treatment = as.factor(auditor$treatment)


model2 <- aov(y ~ block + treatment, data=auditor)
summary(model2)

# If we ignore block effect, treatment effects become less significant 

summary(aov(y ~ treatment, data=auditor))

# Checking model Assumptions

layout(matrix(c(1,2,3,4),2,2)) # optional layout 
plot(model2) # diagnostic plots