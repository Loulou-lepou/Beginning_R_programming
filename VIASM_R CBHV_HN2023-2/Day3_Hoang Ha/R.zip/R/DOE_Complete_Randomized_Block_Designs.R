
# EXAMPLE 1: Air Freshener Sale

freshener = read.table("air.freshener.txt", header = T)
head(freshener)
View(freshener)


freshener$trtmt = factor(freshener$trtmt, labels=LETTERS[1:4])
freshener

# First: try Completely Randomized Design (CRD) with 4 treatments

model0 <- aov(sales ~ trtmt, data = freshener)
summary(model0)

# p-value = 0.41 => treatments appear insignificant 

library(ggplot2)

ggplot(data = freshener, aes(x = store, y = sales, group = trtmt, color = trtmt)) +
  geom_line() + geom_point() +
  labs(x = "Store", y = "Sales", title = "Sales by Store and Treatment") +
  theme_minimal()

# Substantial variation in sales between stores
# Within each store, Treatment D was almost always the worst
    #evidence of treatment effects
# Better take store effect into account 

# ANOVA analysis with Complete Randomized Block Design

freshener$store = factor(freshener$store)
model1 <- aov(sales ~ store + trtmt, data=freshener)
summary(model1)

# Ignoring block effects, treatment effects become insignificant, recall the previous result:
summary(model0)  


# Checking model Assumptions

layout(matrix(c(1,2,3,4),2,2)) # optional layout 
plot(model1) # diagnostic plots


# Latin square
#View(freshener)

#anova(lm(sales ~ store + as.factor(week) + trtmt, data=freshener))
