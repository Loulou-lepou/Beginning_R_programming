# Exampel with popcorn dataset


popcorn =read.table("popcorn.txt", header= T)

head(popcorn)
View(popcorn)

popcorn$brand = as.factor(popcorn$brand)
popcorn$power = as.factor(popcorn$power)
popcorn$time = as.factor(popcorn$time)

# Model:

lm1 = lm(y ~ brand * power * time, data = popcorn)
lm1


# Checking model assumptions

library(ggplot2)
ggplot(popcorn, aes(x = fitted(lm1), y = lm1$res)) + 
  geom_point() +
  labs(x="Fitted Values", y="Residuals")

qqnorm(lm1$res)
qqline(lm1$res)

# 3-way interaction plots

with(subset(popcorn,brand==1),
     interaction.plot(time,power,y,type="b", main="brand 1"))
with(subset(popcorn,brand==2),
     interaction.plot(time,power,y,type="b", main="brand 2"))
with(subset(popcorn,brand==3),
     interaction.plot(time,power,y,type="b", main="brand 3"))

# The 3 plots are on different y-axes.
# Better put them on the same y-axis before comparison

par(mfrow = c(1,3))
with(subset(popcorn,brand==1),
     interaction.plot(time,power,y,type="b",
                      main="brand 1",ylim=c(45,90)))
with(subset(popcorn,brand==2),
     interaction.plot(time,power,y,type="b",
                      main="brand 2",ylim=c(45,90)))
with(subset(popcorn,brand==3),
     interaction.plot(time,power,y,type="b",
                      main="brand 3",ylim=c(45,90)))

# Greater time effect for Brand 2 (steeper lines) than Brands 1 &3
    # higher popping % if popped 4.5 mins than 5 mins for Brand 2 
    # signs of brand:time interactions
# If not placed on the same y-scale, Brand 1 seem to have greater time effect, which is not true
# little power:time interactions for each brand
# Lines in an interaction plot may not be exactly parallel due to noise even if there is no interaction
# We can hence conclude there is little brand:power:time interactions as power:time interactions change little with brand.

# merge all three plots into one

with(popcorn, interaction.plot(brand:time, power, y, type="b"))

# One can consider 2-way interaction 

with(popcorn,interaction.plot(time, brand, y, type="b")) 

# Some evidence of brand:time interactions

with(popcorn,interaction.plot(time, power, y, type="b", ylim=c(60,85)))
with(popcorn,interaction.plot(brand, power, y, type="b", ylim=c(60,85)))

# Perform ANOVA
fit1 = anova(lm1)
fit1
